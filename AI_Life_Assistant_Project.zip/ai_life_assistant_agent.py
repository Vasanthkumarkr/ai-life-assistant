
# AI Life Assistant Agent - Simplified Reference Implementation
# File: ai_life_assistant_agent.py

import os
import argparse
import requests
from duckduckgo_search import ddg
from PIL import Image
import pytesseract
import PyPDF2

# Optional: OpenAI (LLM reasoning)
try:
    import openai
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
    if OPENAI_API_KEY:
        openai.api_key = OPENAI_API_KEY
except:
    openai = None

def llm(prompt):
    if openai is None:
        return "OpenAI API not installed or API key not provided."
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message["content"]
    except Exception as e:
        return str(e)

def web_search(query):
    try:
        results = ddg(query, max_results=5)
        return results
    except Exception as e:
        return str(e)

def read_pdf(path):
    try:
        reader = PyPDF2.PdfReader(path)
        text = ""
        for page in reader.pages:
            text += page.extract_text() + "\n"
        return text
    except Exception as e:
        return str(e)

def analyze_image(path):
    try:
        img = Image.open(path)
        text = pytesseract.image_to_string(img)
        return text
    except Exception as e:
        return str(e)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", type=str, required=True)
    args = parser.parse_args()

    task = args.task

    if task.startswith("summarize_text:"):
        content = task.replace("summarize_text:", "")
        print(llm("Summarize this in 3 bullets: " + content))

    elif task.startswith("plan_study:"):
        content = task.replace("plan_study:", "")
        print(llm("Create a detailed study plan: " + content))

    elif task.startswith("analyze_image:"):
        path = task.replace("analyze_image:path=", "")
        print(analyze_image(path))

    elif task.startswith("read_pdf:"):
        path = task.replace("read_pdf:path=", "")
        print(read_pdf(path))

    elif task.startswith("search:"):
        query = task.replace("search:", "")
        print(web_search(query))

    else:
        print("Unknown task format.")

if __name__ == "__main__":
    main()
