
# AI Life Assistant Agent

A lightweight Python-based AI Agent capable of:
- LLM reasoning (OpenAI)
- Web search (DuckDuckGo)
- OCR from images
- Reading PDFs
- Basic task automation

## Installation
```
pip install -r requirements.txt
```

## Usage
```
python ai_life_assistant_agent.py --task "summarize_text:Explain AI in simple words"
python ai_life_assistant_agent.py --task "plan_study:class=11,subject=physics,days=7"
python ai_life_assistant_agent.py --task "analyze_image:path=image.jpg"
python ai_life_assistant_agent.py --task "read_pdf:path=file.pdf"
python ai_life_assistant_agent.py --task "search:india latest news"
```

Set environment variable for OpenAI:
```
export OPENAI_API_KEY=yourkey
```
